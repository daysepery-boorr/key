# My Key System

A starter website and API for keys used by **your own application**.

## Files
- `server.js` — Express API: create, list, enable/disable, validate keys.
- `public/index.html` — admin page.
- `data/keys.json` — local data file.

## Deploy
1. Upload these files to a GitHub repository.
2. In your hosting service, set the start command to `npm start`.
3. Set an environment variable named `ADMIN_TOKEN` to a long random secret (at least 24 characters). Never commit it to GitHub.
4. Set `DATA_DIR` to a persistent mounted directory on your host (for example `/data`) so keys survive redeploys/restarts. Attach a persistent volume at that exact path.
5. Open your deployed URL, enter the admin token, and generate keys.

## API
- `POST /api/keys` — admin only, creates a key.
- `GET /api/keys` — admin only, lists keys.
- `PATCH /api/keys/:key` with `{"enabled":false}` or `{"enabled":true}` — admin only.
- `POST /api/validate` with `{"key":"MYKEY-..."}` — public; returns `{"valid":true}` or `{"valid":false}`.
- `GET /health` — health check.

Example validation request:
```bash
curl -X POST https://YOUR-HOST/api/validate \
  -H "Content-Type: application/json" \
  -d '{"key":"MYKEY-example"}'
```

## Important
- This is a starter project, not a hardened production service.
- A persistent disk is required for this JSON-file storage. Without it, keys may be lost when the host restarts or redeploys.
- Use HTTPS on the deployed site.
- This project does not include or host third-party scripts. Only host Lua files you own or are authorized to distribute.
- If you need multiple server instances or higher reliability, use a managed database instead of a JSON file.
